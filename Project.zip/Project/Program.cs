// Este arquivo configura o servidor web e inicializa o Razor Pages, permitindo que a aplicação seja executada localmente.
// Razor Pages é uma estrutura do ASP.NET Core que facilita a criação de páginas web.
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Adiciona suporte a Razor Pages
builder.Services.AddRazorPages();

var app = builder.Build();

// Configurações de ambiente
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// Middleware para servir arquivos estáticos (CSS, JS, etc.)
app.UseStaticFiles();

// Configura o roteamento
app.UseRouting();

// Configura endpoints para Razor Pages
app.MapRazorPages();

// Inicializa o app
app.Run();
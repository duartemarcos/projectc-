using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

public class IndexModel : PageModel
{
    public string Title { get; set; }
    public string MetaDescription { get; set; }
    public string MetaKeywords { get; set; }
    public List<Section> Sections { get; set; }

    public void OnGet()
    {
        // Dados fictícios (lorem ipsum)
        Title = "Página Completa com Seções";
        MetaDescription = "Esta é uma página fictícia gerada com lorem ipsum.";
        MetaKeywords = "lorem, ipsum, csharp, aspnetcore";
        Sections = new List<Section>
        {
            new Section
            {
                SectionTitle = "Introdução",
                Content = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vehicula."
            },
            new Section
            {
                SectionTitle = "Sobre",
                Content = "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium."
            },
            new Section
            {
                SectionTitle = "Serviços",
                Content = "Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit."
            },
            new Section
            {
                SectionTitle = "Contato",
                Content = "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur."
            }
        };
    }
}

public class Section
{
    public string SectionTitle { get; set; }
    public string Content { get; set; }
}